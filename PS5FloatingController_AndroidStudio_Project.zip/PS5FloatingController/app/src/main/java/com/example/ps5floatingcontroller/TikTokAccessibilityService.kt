package com.example.ps5floatingcontroller

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Point
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.WindowManager

class TikTokAccessibilityService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onServiceConnected() {
        instance = this
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    fun back() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    // TikTok's layout can change. These are approximate right-side control locations.
    fun tapFraction(xFraction: Float, yFraction: Float) {
        val size = Point()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(size)
        tap(size.x * xFraction, size.y * yFraction)
    }

    fun swipe(up: Boolean) {
        val size = Point()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealSize(size)
        val x = size.x * 0.50f
        val startY = if (up) size.y * 0.78f else size.y * 0.30f
        val endY = if (up) size.y * 0.28f else size.y * 0.78f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 280))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun tap(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y); lineTo(x + 1, y + 1) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        dispatchGesture(gesture, null, null)
    }

    companion object {
        @Volatile var instance: TikTokAccessibilityService? = null
            private set
    }
}
