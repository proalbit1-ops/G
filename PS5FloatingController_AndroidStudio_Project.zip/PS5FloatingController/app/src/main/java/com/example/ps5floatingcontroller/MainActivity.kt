package com.example.ps5floatingcontroller

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(20, 22, 30))
        }
        val title = TextView(this).apply {
            text = "PS5 Floating Controller"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val info = TextView(this).apply {
            text = "1. Allow display over other apps.\n2. Enable the accessibility service.\n3. Start the floating controller, then open TikTok."
            textSize = 16f
            setTextColor(Color.LTGRAY)
            setPadding(0, 20, 0, 20)
        }
        fun addButton(label: String, action: () -> Unit) {
            layout.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        layout.addView(title)
        layout.addView(info)
        addButton("Allow floating window") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addButton("Enable controller accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("Start floating controller") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, ControllerOverlayService::class.java))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        }
        addButton("Stop floating controller") {
            stopService(Intent(this, ControllerOverlayService::class.java))
        }
        setContentView(layout)
    }
}
