package com.example.ps5floatingcontroller

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable

class ControllerOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var params: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (panel == null) showController()
        return START_STICKY
    }

    private fun showController() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(8, 8, 8, 8)
            background = GradientDrawable().apply {
                setColor(0xB8202430.toInt())
                cornerRadius = 22f
                setStroke(2, 0xFF9AA4B2.toInt())
            }
        }
        val header = TextView(this).apply {
            text = "PS5  •  drag here"
            setTextColor(Color.WHITE)
            textSize = 12f
            gravity = Gravity.CENTER
            setPadding(8, 5, 8, 8)
        }
        root.addView(header)
        val row1 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row1.addView(makeButton("△", 0xFF2563EB.toInt()) { TikTokAccessibilityService.instance?.tapFraction(0.86f, 0.68f) })
        row1.addView(makeButton("□", 0xFF2563EB.toInt()) { TikTokAccessibilityService.instance?.tapFraction(0.86f, 0.58f) })
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(makeButton("✕", 0xFF2563EB.toInt()) { TikTokAccessibilityService.instance?.tapFraction(0.86f, 0.50f) })
        row2.addView(makeButton("○", 0xFF2563EB.toInt()) { TikTokAccessibilityService.instance?.back() })
        val row3 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row3.addView(makeButton("L2", 0xFF424B5A.toInt()) { TikTokAccessibilityService.instance?.swipe(false) })
        row3.addView(makeButton("R2", 0xFF424B5A.toInt()) { TikTokAccessibilityService.instance?.swipe(true) })
        root.addView(row1); root.addView(row2); root.addView(row3)
        header.setOnTouchListener(DragTouchListener())
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 220 }
        panel = root
        wm.addView(root, params)
    }

    private fun makeButton(label: String, color: Int, action: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            textSize = 19f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(color); cornerRadius = 40f; setStroke(1, Color.WHITE) }
            val size = (resources.displayMetrics.density * 48).toInt()
            layoutParams = LinearLayout.LayoutParams(size, size).apply {
                setMargins(4, 4, 4, 4)
            }
            setOnClickListener { action() }
        }
    }

    private inner class DragTouchListener : View.OnTouchListener {
        private var startX = 0
        private var startY = 0
        private var touchX = 0f
        private var touchY = 0f
        override fun onTouch(v: View, event: MotionEvent): Boolean {
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = event.rawX; touchY = event.rawY
                    return true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX - (event.rawX - touchX)).toInt().coerceAtLeast(0)
                    params.y = (startY + (event.rawY - touchY)).toInt().coerceAtLeast(0)
                    wm.updateViewLayout(panel, params)
                    return true
                }
            }
            return true
        }
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
}
