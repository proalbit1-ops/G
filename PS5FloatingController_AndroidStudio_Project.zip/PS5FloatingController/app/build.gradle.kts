plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.ps5floatingcontroller"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.ps5floatingcontroller"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
