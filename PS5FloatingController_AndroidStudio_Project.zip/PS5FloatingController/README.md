# PS5 Floating Controller (Android starter)

This is a starter Android Studio project for a movable floating controller overlay.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync and install the Android SDK platform 35 if prompted.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the debug APK on your Redmi phone.

## First use
1. Open the app.
2. Tap **Allow floating window** and grant the permission.
3. Tap **Enable controller accessibility**. Find “PS5 Floating Controller” in Accessibility settings and enable it.
4. Return to the app and tap **Start floating controller**.
5. Open TikTok.

## Current button mapping
- X: approximate Like tap
- O: Android Back
- Triangle: approximate Share tap
- Square: approximate Comments tap
- L2: swipe down (previous video)
- R2: swipe up (next video)

## Important limitations
- This is source code, not a prebuilt or tested APK. Build it with Android Studio.
- TikTok can change its layout and button positions. The Like/Share/Comments tap coordinates are approximate and may need adjustment for your phone, TikTok version, display scaling, or orientation.
- Accessibility permission is powerful. This service only dispatches the gestures described in the source; review the code and enable it only if you trust it.
- Android/MIUI/HyperOS may restrict background overlays. If the overlay disappears, allow the app to run in the background/autostart in system settings.
- The floating panel is intentionally compact and can be dragged by its “PS5 • drag here” header. It does not yet include analog sticks, L1/R1, or an in-app editor.
